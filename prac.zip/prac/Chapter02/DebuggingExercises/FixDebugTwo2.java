public class FixDebugTwo2
//  This application performs arithmetic with two integers
{
   public static void main(String args[])
   {
      int a, b;
      a = 7;
      b = 4;
      System.out.println("The sum is " + (a + b));
      System.out.println("The difference is " + (a - b));
      System.out.println("The product is " + (a * b));
   }
}
