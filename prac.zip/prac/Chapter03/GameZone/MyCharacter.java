public class MyCharacter
{
   private int age;
   private int numberOfLegs;
   private int numberOfEyes;
   public int getAge()
   {
      return age;
   }
   public int getLegs()
   {
      return numberOfLegs;
   }
   public int getEyes()
   {
      return numberOfEyes;
   }
   public void setAge(int a)
   {
      age = a;
   } 
   public void setLegs(int l)
   {
      numberOfLegs = l;
   }
   public void setEyes(int e)
   {
      numberOfEyes = e;
   }
} 
   