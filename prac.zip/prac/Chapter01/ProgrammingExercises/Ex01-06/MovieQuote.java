// MovieQuote.java
// Chapter 1, Exercise #6
// Displays a movie quote

class MovieQuote
{
  public static void main(String[] args)
  {
     System.out.println("Rosebud."); //Display the string
  }
}