public class First
{
   public static void main(String[] args)
   {
      System.out.println("My new and improved");
      System.out.println("First Java application");
   }
}
