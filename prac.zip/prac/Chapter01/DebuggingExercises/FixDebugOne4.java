import javax.swing.JOptionPane;
public class FixDebugOne4
{
  public static void main(String[] args)
  {
     JOptionPane.showMessageDialog(null, "First GUI program");
  }
}
