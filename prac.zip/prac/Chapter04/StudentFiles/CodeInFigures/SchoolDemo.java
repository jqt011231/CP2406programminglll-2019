public class SchoolDemo
{
   public static void main(String[] args)
   {
      School mySchool = new School
         ("Audubon Elementary",
         "3500 Hoyne", 60618, 350);
      mySchool.display();
   }
}
