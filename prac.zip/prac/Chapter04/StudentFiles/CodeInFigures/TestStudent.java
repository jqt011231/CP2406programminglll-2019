public class TestStudent
{
   public static void main(String[] args)
   {
      Student aPsychMajor = new Student(111, 3.5);
      aPsychMajor.showStudent();
   }
}