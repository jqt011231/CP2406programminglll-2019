public class FixDebugBook
{
   protected int pages;
   public FixDebugBook(int pgs)
   {
      pages = pgs;
   }
   public int getPages()
   {
      return pages;
   }
}