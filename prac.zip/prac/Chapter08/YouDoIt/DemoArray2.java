public class DemoArray2
{
   public static void main(String[] args)
   {
      double[] salaries = {6.25, 6.55, 10.25, 16.85};
      System.out.println("Salaries one by one are:");
      System.out.println(salaries[0]);
      System.out.println(salaries[1]);
      System.out.println(salaries[2]);
      System.out.println(salaries[3]);
   }
}
 