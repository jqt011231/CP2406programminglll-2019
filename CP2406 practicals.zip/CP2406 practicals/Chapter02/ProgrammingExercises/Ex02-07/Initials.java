// Initials.java

class Initials
{    
   public static void main(String[] args) 
   {  
      char init1 = 'J';
      char init2 = 'M';
      char init3 = 'F';
      System.out.println(init1 + "." + init2 +
          "."	+ init3 + ".");
   }
}