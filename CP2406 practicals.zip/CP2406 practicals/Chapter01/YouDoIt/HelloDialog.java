// Filename HelloDialog.java
// Written by Sally Student
// Written on September 2, 2016
import javax.swing.JOptionPane;
public class HelloDialog
{
   public static void main(String[] args)
   {
      JOptionPane.showMessageDialog(null, "Hello, world!");
   }
}
