// MovieQuoteInfo.java
// Chapter 1,Exercise #7
// Displays quote, character, movie, and year
class MovieQuoteInfo
{
   public static void main(String[] args)
   {
      System.out.println("Rosebud.");
      System.out.println("Charles Foster Kane");
      System.out.println("Citizen Kane");
      System.out.println("1941");
   }
}