// Comments.java
// Chapter 1, Exercise #10
// Displays comments
class Comments
{
   public static void main(String[] args)
   {
      System.out.println("Program comments are nonexecuting statements ");
      System.out.println("you add to a file for the purpose of documentation.");
      // line comments
      // Program comments are nonexecuting statements 
      // you add to a file for the purpose of documentation.
      // block comment
      /* Program comments are nonexecuting statements 
         you add to a file for the purpose of documentation. */
      // javadoc comment
      /** Program comments are nonexecuting statements 
          you add to a file for the purpose of documentation.  */
   }
}