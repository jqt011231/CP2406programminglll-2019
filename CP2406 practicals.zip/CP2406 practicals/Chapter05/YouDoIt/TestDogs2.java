public class TestDogs2
{
   public static void main(String[] args)
   {
      DogTriathlonParticipant2 dog1 =
        new DogTriathlonParticipant2("Bowser", 2, 85, 89, 0);
      dog1.display();
      DogTriathlonParticipant2 dog2 =
        new DogTriathlonParticipant2("Rush", 3, 78, 72, 80);
      dog2.display();
      DogTriathlonParticipant2 dog3 =
        new DogTriathlonParticipant2("Ginger", 3, 90, 86, 72);
      dog3.display();
   }
}
