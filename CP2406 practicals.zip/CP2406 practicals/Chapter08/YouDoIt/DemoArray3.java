public class DemoArray3
{
   public static void main(String[] args)
   {
      double[] salaries = {6.25, 6.55, 10.25, 16.85};
      System.out.println("Salaries one by one are:");
      for(int x = 0; x < salaries.length; ++x)
         System.out.println(salaries[x]);
   }
}
 