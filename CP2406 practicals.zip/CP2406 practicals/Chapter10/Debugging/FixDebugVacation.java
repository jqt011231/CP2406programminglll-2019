public class FixDebugVacation
{
   protected int days;
   public FixDebugVacation()
   {
      days = 10;
   }
   public int getDays()
   {
      return days;
   }
}
