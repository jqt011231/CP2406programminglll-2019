public class CreateAliens
{
   public static void main(String[] args)
   {
      Martian aMartian = new Martian();
      Jupiterian aJupiterian = new Jupiterian();
      System.out.println("Martian: " +
         aMartian.toString());
      System.out.println("Jupiterian: " +
         aJupiterian.toString());
   }
}