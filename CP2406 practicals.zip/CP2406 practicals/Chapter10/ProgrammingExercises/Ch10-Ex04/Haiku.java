public class Haiku extends Poem
{
   private String title;
   private int lines;
   public Haiku(String name)
   {
      super(name, 3);
   }
}
